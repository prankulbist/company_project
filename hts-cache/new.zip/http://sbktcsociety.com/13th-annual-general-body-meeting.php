


<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US"><![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
    <!--<![endif]-->    
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>BK Society || Home</title>
		<!--Start Header script-->
		<link rel='stylesheet' href='wp-content/plugins/LayerSlider/css/layerslider2cb6.css' type='text/css' media='all' />
<link rel='stylesheet'   href='wp-content/plugins/revslider/rs-plugin/css/settings84bb.css' type='text/css' media='all' />
<style type='text/css'>
   .tp-caption a{color:#57a2bc;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#323232}
</style>
<link rel='stylesheet' href='wp-content/themes/website/style.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/fonts8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/adaptive8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/cmsms-woocommerce-style8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jackbox8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jquery.jPlayer3c94.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jquery.isotope5d6b.css' type='text/css' media='screen' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='theme-ie-css'  href='http://industrial.cmsmasters.net/wp-content/themes/website/css/ie.css?ver=1.0.0' type='text/css' media='screen' />
<![endif]-->
<!--[if lt IE 9]>
<link rel='stylesheet' id='theme-ieCss3-css'  href='http://industrial.cmsmasters.net/wp-content/themes/website/css/ieCss3.php?ver=1.0.0' type='text/css' media='screen' />
<![endif]-->
<link rel='stylesheet'   href='http://fonts.googleapis.com/css?family=Raleway%3A200%2C400%2C500%2C600%2C700&amp;ver=3.9.2' type='text/css' media='all' />
<script type='text/javascript' src='wp-content/themes/website/js/modernizr.custom.all.min16b9.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/respond.minf488.js'></script>
<script type='text/javascript' src='jquery/jquery.js'></script>
<script type='text/javascript' src='jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/layerslider.kreaturamedia.jquery2cb6.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/jquery-easing-1.36f3e.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/jquerytransite2dc.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/layerslider.transitions2cb6.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min84bb.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min84bb.js'></script>
<script type="text/javascript">var templateURL = "wp-content/themes/website/index.php";</script>
<style type="text/css">
	body {background-color :#ffffff; background-image :none; background-position :top center; background-repeat:repeat; background-attachment : scroll;}
	#middle.cmsms_middle_margin{margin-top:110px; }
	#header > .header_inner { height : 120px; }
	#header.fixed_header + * { margin-top : 100px; }
	#header > .header_inner > a.logo { top : 10px; left : 0px; } 
	.header_inner:after { width : 255px; } 
	#header > .header_inner > a.logo > img { width : 170px; height : 100px; }
	#header nav { top : 55px; left : 200px; } 
	#header .social_icons { top : 55px; left : 255px; } 
	#header .search_line { top : 95px; left : 255px; } 
	.header_html { top : 15px; right : 0px; }
	#header.fixed_header > .header_inner { height : 110px; }
	#header.fixed_header > .header_inner > a.logo { top : 10px; }
	#header.fixed_header nav { top : 50px; } 
	#header.fixed_header .social_icons { top : 60px; } 
	#header.fixed_header .search_line { top : 90px; }
	@media only screen and (max-width : 1024px) { .cmsms_responsive #middle.cmsms_middle_margin { margin-top : 0px; } .cmsms_responsive .header_inner:after { margin-left : 5%; } .cmsms_responsive #header nav { top : auto; left : auto; } .cmsms_responsive #header > .header_inner > a.logo { top : auto; left : auto; } .cmsms_responsive #header > .header_inner { height : auto; } }
	@media only screen and (max-width : 767px) 
	{ 
		.cmsms_responsive #header .search_line, .cmsms_responsive #header .social_icons { top : auto; left : auto; } 
	} 
	@media only screen and (max-width : 450px) 
	{ 
		.cmsms_responsive .header_html { top : auto; }
		.cmsms_responsive #header > .header_inner > a.logo { width : 90%; height : auto; } 
		.cmsms_responsive #header > .header_inner > a.logo > img { margin : 0 auto; } 
		.cmsms_responsive .header_inner:after { width : 90%; } 
	} 
</style>
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;background:none !important; }</style>		<!--Finish Header script-->
	</head>
	<body >
		<!--Start Page-->
		<section id="page" class="csstransition cmsms_responsive hfeed site">
			<a href="#" id="slide_top"></a>
			<!--Start Container-->
			<div class="container set_fixed">
				<!--Start Header-->
				<header class="header_position" id="header">
	<div class="header_inner">
		<a href="index.php" title="SHREE BADRI KEDAR CO-OPERATIVE" class="logo">
			<img src="wp-content/themes/website/img/logo.png" alt="SHREE BADRI KEDAR CO-OPERATIVE" />
		</a>
		<div style="font-size:25px;top:10px;left:220px;position:absolute;font-weight:bold;color:#f58149;line-height:30px;">
			SHREE BADRI KEDAR CO-OPERATIVE <br/>URBAN THRIFT & CREDIT SOCIETY LTD. <span style="font-size:13px;font-weight:bold;color:#000;">Registration no.: S/W 16(U)/2002</span>
		</div>
		
		<!--<a class="search_but" href="javascript:void(0);"></a>
		<a class="social_but social_but_fixed" href="javascript:void(0);"></a>-->
			
		<!--Start Navigation-->
		<nav role="navigation" class="">
			<ul id="navigation" class="navigation">
				<li class="current-menu-ancestor current-menu-parent"><a href="index.php"><span>Home</span></a> </li>
				<li ><a href="aboutus.php"><span>About Us</span></a></li>
				<li class="dropdown">
					<a href="#"><span>Management</span></a>
					<ul class="sub-menu">
						<li ><a href="board-of-management.php"><span>Board of Management </span></a></li>
						<li ><a href="gallery.php"><span>Gallery</span></a></li>
					</ul>
				</li>
				<li><a href="contactus.php"><span>Contact Us</span></a></li>
				<li class="dropdown">
					<a href="#"><span>Quick Access</span></a>
					<ul class="sub-menu">
						<!--<li ><a href="member-list.php"><span>Member List </span></a></li>-->
						<li ><a href="emicalculator.php"><span>Loan EMI Calculator</span></a></li>
						<li ><a href="schemes.php"><span>FD Schemes</span></a></li>
						<li ><a href="members-welfare-scheme.php"><span>Members Welfare Scheme</span></a></li>
						
					</ul>
				</li>
				<li ><a href="bkadmin/" target="_blank"><span>Admin login</span></a></li>
			</ul>
		</nav>
		<!-- <div class="search_line">
		   <form method="get" action="#">
				<div class="one_half first_column">
					 <input placeholder="User Id" value="" type="text">
				</div>
				<div class="one_half">
					 <input placeholder="password" value="" type="password">  <input placeholder="LogIn" value="Login" type="button" class="button_small">
				</div> 
				
		   </form>
		</div>
		<ul class="social_icons">
			<li>
			   <a target="_blank" href="#" title="LinkedIn">
			   <img src="images/linkedin.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="LinkedIn">LinkedIn</a>
			</li>
			<li>
			   <a target="_blank" href="#" title="Facebook">
			   <img src="images/facebook.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Facebook">Facebook</a>
			</li>
			<li>
			   <a href="#" title="Google">
			   <img src="images/google-plus.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Google">Google</a>
			</li>
			
			<li>
			   <a href="#" title="Twitter">
			   <img src="images/twitter.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Twitter">Twitter</a>
			</li>
		</ul>
		<div class="cl"></div>-->
		<!-- _________________________ Finish Navigation _________________________ -->
	</div>
</header>				<!--Finish Header-->
				<!-- _________________________ Start Middle _________________________ -->
				<section id="middle" class=" cmsms_middle_margin">
					<div class="headline">
						<div class="width100">
							<div><h1 class="heading_title_nomg">13th Annual General Body Meeting</h1></div>
							<div class="cmsms_breadcrumbs">
								<a href="index.php" class="home"></a>
								<span class="breadcrumbs_sep"> / </span>
								<a href="#" >Management</a>
								<span class="breadcrumbs_sep"> / </span>
								<a href="gallery.php" >Gallery</a>
								<span class="breadcrumbs_sep"> / </span>
								<span><b>13th Annual General Body Meeting</b></span>
							</div>
						</div>
					</div>
					<div class="content_wrap fullwidth">
						<!--Start Content-->
						<section id="middle_content" >
							<div class="entry">
								<div class="cmsms_cc">
									<div class="one_first first_column" >
										<p><b>13TH ANNUAL GENERAL BODY MEETING EVENT GALLERY. </b></p>
									</div>
									<div class="one_fourth first_column" >
										<div class="resize">
											<figure>
												<a href="images/13th-agm/1.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox"><img height="500"  src="images/13th-agm/1.jpg" class="fullwidth" alt="Gallery" title="Gallery" /></a>
												
											</figure>
										</div>	
									</div>
									<div class="one_fourth" >
										<div class="resize">
											<figure>
												<a href="images/13th-agm/2.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox"><img height="500"  src="images/13th-agm/2.jpg" class="fullwidth" alt="Gallery" title="Gallery" /></a>
												
											</figure>
										</div>	
									</div>
									<div class="one_fourth" >
										<div class="resize">
											<figure>
												<a href="images/13th-agm/3.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img height="500"  src="images/13th-agm/3.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>	
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/4.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img height="500" src="images/13th-agm/4.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>	
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/5.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/5.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>	
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/5.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img height="500" src="images/13th-agm/5.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/6.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/6.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/7.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/7.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/8.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/8.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/9.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/9.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >
										<div class="resize">
											<figure>
												<a href="images/13th-agm/10.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img height="500"  src="images/13th-agm/10.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>	
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/11.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img height="500" src="images/13th-agm/11.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>	
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/12.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/12.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>	
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/13.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img height="500" src="images/13th-agm/13.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/14.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/14.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/15.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/15.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/16.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/16.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/17.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/17.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/18.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/18.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/19.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/19.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/20.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/20.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/21.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/21.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/22.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/22.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/23.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/23.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/24.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/24.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/25.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/25.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/26.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/26.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/27.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/27.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/28.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/28.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/29.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/29.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/30.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/30.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/31.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/31.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/32.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/32.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/33.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/33.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/34.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/34.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_fourth" >	
										<div class="resize">
											<figure>
												<a href="images/13th-agm/35.jpg" data-group="img_168" title="Gallery" class="preloader highImg jackbox">
													<img  height="500" src="images/13th-agm/35.jpg" class="fullwidth" alt="Gallery" title="Gallery" />
												</a>
												
											</figure>
										</div>
									</div>
									<div class="one_first first_column" >
										<div>
											<div class="cl"></div>
										</div>
									</div>	
								</div>
							</div>
						</section>
						<!--Finish Content-->
						<div class="cl"></div>
					</div>
				</section>
				<!--Start Bottom-->
				<script src="jquery/js_jquery-2.2.0.min.js"></script>		
		
<script>
	$(document).ready(function (e){
		$("#frmContact1").on('submit',(function(e){
			e.preventDefault();
			$("#mail-status").hide();
			$('#send-message').hide();
			$('#loader-icon').show();
		//	response.type='message';
			$.ajax({
				url: "sendmyemail_home.php",
				type: "POST",
				dataType:'json',
				data: {
				//"name":$('input[name="name"]').val(),
				"email":$('input[name="email"]').val(),
				//"phone":$('input[name="phone"]').val(),
				//"subject":$('input[name="subject"]').val(),
				"content":$('textarea[name="content"]').val(),
				//"g-recaptcha-response":$('textarea[id="g-recaptcha-response"]').val()
				    
				},				
				success: function(response){
				$("#mail-status").show();
				$('#loader-icon').hide();
				if(response.type == "error") {
					$('#send-message').show();
					$("#mail-status").attr("class","error");				
				} else if(response.type == "message"){
					$('#send-message').hide();
					$("#mail-status").attr("class","success");							
				}
				$("#mail-status").html(response.text);	
				},
				error: function(){} 
			});
		}));
	});
    </script>
    


    <style>

		#message {  padding: 0px 40px 0px 0px; }
		#mail-status {
			padding: 12px 20px;
			width: 100%;
			display:none; 
			font-size: 1em;
			font-family: "Georgia", Times, serif;
			color: rgb(40, 40, 40);
		}
	  .error{background-color: #F7902D;  margin-bottom: 40px;}
	  .success{background-color: #48e0a4; }
		.g-recaptcha {margin: 0 0 25px 0;}	  
	</style>

<section id="bottom">
	<div class="bottom_inner">
		<div class="bottom_content one_fourth_woocommerce">
			<div class="one_fourth">
				<aside class="widget_recent_entries">
					<h5 class="widgettitle">Site Link</h5>
					<ul>			
						<li><a href="index.php" title="">Home</a></li>
						<li><a href="aboutus.php" title="">About Us</a></li>
						<li ><a href="board-of-management.php"><span>Board of Management</span></a></li>
						<li ><a href="gallery.php"><span>Gallery</span></a></li>
					   <li><a href="contactus.php" title="">Contact Us</a> </li>
					</ul>
				</aside>
			</div>
			<div class="one_fourth">
				<aside class="widget_recent_entries">
					<h5 class="widgettitle">Quick Access</h5>
					<ul>			
						
						<li ><a href="emicalculator.php"><span>Loan EMI Calculator</span></a></li>
						<li ><a href="schemes.php"><span>FD Schemes</span></a></li>
						<li ><a href="members-welfare-scheme.php"><span>Members Welfare Scheme</span></a></li>
					</ul>
				</aside>
			</div>
			<div class="cl_resp"></div>
			<div class="one_fourth">
				<aside class="widget_custom_contact_info_entries">
					<h5 class="widgettitle">Contact Info</h5>
					<span class="contact_widget_name"><strong>SBK Society - Head Office </strong></span><br /><br />
					<span class="contact_widget_address">
						<span ><b>Address</b></span><br />
						Choudhary Satbir House, 139-B 1st Floor,<br/> Mohammad Pur, Near Bhikaji Cama Place, New Delhi - 110066, India.
					</span>
					<br /><br />
					<span class="contact_widget_phone"><!--11 26175215-->
						<span style="display:inline-block; width:25%;"><b>Tel:&nbsp;</b></span>011 47028705
					</span>
					<br />
					<span class="contact_widget_phone">
						<span style="display:inline-block; width:25%;"><b>Fax:&nbsp;</b></span>+91 9891955999
					</span>
					<br />
					<span class="contact_widget_phone">
						<span style="display:inline-block; width:25%;"><b>Email:&nbsp;</b></span>sbktcsociety@gmail.com 
					</span>
	
					
				</aside>
				
			</div>
			<div class="one_fourth">
				 <aside  class="widget_custom_contact_form_entries">
					 <h5 class="widgettitle">Contact us</h5>
					 <div class="cmsms-form-builder">
						<form id="frmContact1" action="" method="POST" novalidate="novalidate">
						   <div class="form_info cmsms_input">
							  <label for="">Your email <span class="color_3">*</span></label>
							  <div class="form_field_wrap">
								 <input type="text" vid="email" name="email" alue="" class="validate[required]" />
							  </div>
						   </div>
						   <div class="cl"></div>
						   <div class="form_info cmsms_textarea">
							  <label for="">Message</label>
							  <div class="form_field_wrap">
								 <textarea  cols="30" rows="6" id="comment-content" name="content"></textarea>
							  </div>
						   </div>
						   <div class="cl"></div>
						  	<div id="mail-status"></div>
						   <div class="fl">	<button style="border:0px;" class="button_small" type="Submit" id="send-message" style="clear:both;">Send Message</button></div>
						   <div class="cl"></div>
						</form>
							<div id="loader-icon" style="display:none;"><img src="loader.gif" /></div>
					 </div>
				  </aside>
			</div>
		</div>
	</div>
</section>				<!--Finish Bottom-->
				<a href="javascript:void(0);" id="slide_top"></a>
			</div>
			<!--Finish Container-->
			<!--Start Footer-->
			<footer id="footer" role="contentinfo">
	<div class="footer_inner">
		<span class="copyright"><b>&copy; 2014. SBK Society. Designed By: <a href="http://www.delightaid.com/" target="_blank">Delightaid</a></b></span>
		<ul class="social_icons">
			<li>
			   <a target="_blank" href="#" title="LinkedIn">
			   <img src="images/linkedin.png" alt="#" />
			   </a>
			</li>
			<li>
			   <a target="_blank" href="#" title="Facebook">
			   <img src="images/facebook.png" alt="#" />
			   </a>
			</li>
			<li>
			   <a href="#" title="Google">
			   <img src="images/google-plus.png" alt="#" />
			   </a>
			</li>
			
			<li>
			   <a href="#" title="Twitter">
			   <img src="images/twitter.png" alt="#" />
			   </a>
			</li>
		</ul>
	</div>
</footer>
			<!--Finish Footer-->
		</section>   
		<!--Start Footer-->
		<script type='text/javascript' src='wp-content/themes/website/js/jquery.easing.min6f3e.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jackbox-lib8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jackbox8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jquery.script8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jquery.tweet.mine7f0.js'></script>		<!--Finish Footer-->
	</body>
</html>