<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US"><![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
    <!--<![endif]-->    
	<head>
		<meta charset="UTF-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>Shri Badri Kedar - SBK Society</title>
		<!--Start Header script-->
		<link rel='stylesheet' href='wp-content/plugins/LayerSlider/css/layerslider2cb6.css' type='text/css' media='all' />
<link rel='stylesheet'   href='wp-content/plugins/revslider/rs-plugin/css/settings84bb.css' type='text/css' media='all' />
<style type='text/css'>
   .tp-caption a{color:#57a2bc;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#323232}
</style>
<link rel='stylesheet' href='wp-content/themes/website/style.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/fonts8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/adaptive8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/cmsms-woocommerce-style8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jackbox8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jquery.jPlayer3c94.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jquery.isotope5d6b.css' type='text/css' media='screen' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='theme-ie-css'  href='http://industrial.cmsmasters.net/wp-content/themes/website/css/ie.css?ver=1.0.0' type='text/css' media='screen' />
<![endif]-->
<!--[if lt IE 9]>
<link rel='stylesheet' id='theme-ieCss3-css'  href='http://industrial.cmsmasters.net/wp-content/themes/website/css/ieCss3.php?ver=1.0.0' type='text/css' media='screen' />
<![endif]-->
<link rel='stylesheet'   href='http://fonts.googleapis.com/css?family=Raleway%3A200%2C400%2C500%2C600%2C700&amp;ver=3.9.2' type='text/css' media='all' />
<script type='text/javascript' src='wp-content/themes/website/js/modernizr.custom.all.min16b9.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/respond.minf488.js'></script>
<script type='text/javascript' src='jquery/jquery.js'></script>
<script type='text/javascript' src='jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/layerslider.kreaturamedia.jquery2cb6.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/jquery-easing-1.36f3e.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/jquerytransite2dc.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/layerslider.transitions2cb6.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min84bb.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min84bb.js'></script>
<script type="text/javascript">var templateURL = "wp-content/themes/website/index.php";</script>
<style type="text/css">
	body {background-color :#ffffff; background-image :none; background-position :top center; background-repeat:repeat; background-attachment : scroll;}
	#middle.cmsms_middle_margin{margin-top:110px; }
	#header > .header_inner { height : 120px; }
	#header.fixed_header + * { margin-top : 100px; }
	#header > .header_inner > a.logo { top : 10px; left : 0px; } 
	.header_inner:after { width : 255px; } 
	#header > .header_inner > a.logo > img { width : 170px; height : 100px; }
	#header nav { top : 55px; left : 200px; } 
	#header .social_icons { top : 55px; left : 255px; } 
	#header .search_line { top : 95px; left : 255px; } 
	.header_html { top : 15px; right : 0px; }
	#header.fixed_header > .header_inner { height : 110px; }
	#header.fixed_header > .header_inner > a.logo { top : 10px; }
	#header.fixed_header nav { top : 50px; } 
	#header.fixed_header .social_icons { top : 60px; } 
	#header.fixed_header .search_line { top : 90px; }
	@media only screen and (max-width : 1024px) { .cmsms_responsive #middle.cmsms_middle_margin { margin-top : 0px; } .cmsms_responsive .header_inner:after { margin-left : 5%; } .cmsms_responsive #header nav { top : auto; left : auto; } .cmsms_responsive #header > .header_inner > a.logo { top : auto; left : auto; } .cmsms_responsive #header > .header_inner { height : auto; } }
	@media only screen and (max-width : 767px) 
	{ 
		.cmsms_responsive #header .search_line, .cmsms_responsive #header .social_icons { top : auto; left : auto; } 
	} 
	@media only screen and (max-width : 450px) 
	{ 
		.cmsms_responsive .header_html { top : auto; }
		.cmsms_responsive #header > .header_inner > a.logo { width : 90%; height : auto; } 
		.cmsms_responsive #header > .header_inner > a.logo > img { margin : 0 auto; } 
		.cmsms_responsive .header_inner:after { width : 90%; } 
	} 
</style>
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;background:none !important; }</style>		<!--Finish Header script-->
		<style>
		.mar{font: bold 18px/26px "Raleway",Arial,Helvetica,"Nimbus Sans L",sans-serif;}
		</style>
		<style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
  opacity: 1;
  transition: opacity 0.6s;font-size: 18px;font-style: italic;
  margin-bottom: 15px;
}

.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: #ff9800;}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
	</head>
	<body >
		<!--Start Page-->
		<section id="page" class="csstransition cmsms_responsive hfeed site">
			<a href="#" id="slide_top"></a>
			<!--Start Container-->
			<div class="container set_fixed">
				<!--Start Header-->
				<header class="header_position" id="header">
	<div class="header_inner">
		<a href="index.php" title="SHREE BADRI KEDAR CO-OPERATIVE" class="logo">
			<img src="wp-content/themes/website/img/logo.png" alt="SHREE BADRI KEDAR CO-OPERATIVE" />
		</a>
		<div style="font-size:25px;top:10px;left:220px;position:absolute;font-weight:bold;color:#f58149;line-height:30px;">
			SHREE BADRI KEDAR CO-OPERATIVE <br/>URBAN THRIFT & CREDIT SOCIETY LTD. <span style="font-size:13px;font-weight:bold;color:#000;">Registration no.: S/W 16(U)/2002</span>
		</div>
		
		<!--<a class="search_but" href="javascript:void(0);"></a>
		<a class="social_but social_but_fixed" href="javascript:void(0);"></a>-->
			
		<!--Start Navigation-->
		<nav role="navigation" class="">
			<ul id="navigation" class="navigation">
				<li class="current-menu-ancestor current-menu-parent"><a href="index.php"><span>Home</span></a> </li>
				<li ><a href="aboutus.php"><span>About Us</span></a></li>
				<li class="dropdown">
					<a href="#"><span>Management</span></a>
					<ul class="sub-menu">
						<li ><a href="board-of-management.php"><span>Board of Management </span></a></li>
						<li ><a href="gallery.php"><span>Gallery</span></a></li>
					</ul>
				</li>
				<li><a href="contactus.php"><span>Contact Us</span></a></li>
				<li class="dropdown">
					<a href="#"><span>Quick Access</span></a>
					<ul class="sub-menu">
						<!--<li ><a href="member-list.php"><span>Member List </span></a></li>-->
						<li ><a href="emicalculator.php"><span>Loan EMI Calculator</span></a></li>
						<li ><a href="schemes.php"><span>FD Schemes</span></a></li>
						<li ><a href="members-welfare-scheme.php"><span>Members Welfare Scheme</span></a></li>
						
					</ul>
				</li>
				<li ><a href="bkadmin/" target="_blank"><span>Admin login</span></a></li>
			</ul>
		</nav>
		<!-- <div class="search_line">
		   <form method="get" action="#">
				<div class="one_half first_column">
					 <input placeholder="User Id" value="" type="text">
				</div>
				<div class="one_half">
					 <input placeholder="password" value="" type="password">  <input placeholder="LogIn" value="Login" type="button" class="button_small">
				</div> 
				
		   </form>
		</div>
		<ul class="social_icons">
			<li>
			   <a target="_blank" href="#" title="LinkedIn">
			   <img src="images/linkedin.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="LinkedIn">LinkedIn</a>
			</li>
			<li>
			   <a target="_blank" href="#" title="Facebook">
			   <img src="images/facebook.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Facebook">Facebook</a>
			</li>
			<li>
			   <a href="#" title="Google">
			   <img src="images/google-plus.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Google">Google</a>
			</li>
			
			<li>
			   <a href="#" title="Twitter">
			   <img src="images/twitter.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Twitter">Twitter</a>
			</li>
		</ul>
		<div class="cl"></div>-->
		<!-- _________________________ Finish Navigation _________________________ -->
	</div>
</header>				<!--Finish Header-->
				<!--Start Middle-->
				<section id="middle" class=" cmsms_middle_margin">
				<!--Start Top-->
				<section id="top">
					<div class="wrap_rev_slider">
						
						<!-- START REVOLUTION SLIDER 4.6.0 fullwidth mode -->
						<link href="http://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet" type="text/css" media="all" />
						<div id="rev_slider_2_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" style="margin:0px auto;background-color:#E9E9E9;padding:0px;margin-top:0px;margin-bottom:0px;max-height:500px;">
							<div id="rev_slider_2_1" class="rev_slider fullwidthabanner" style="display:none;max-height:500px;height:500px;">
								<ul>	
									<!-- SLIDE  -->
									<li data-transition="boxfade" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
										<!-- MAIN IMAGE -->
										<img src="images/slider/11.jpg"  alt="21"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
										<!-- LAYERS -->
									</li>
									<!-- SLIDE  -->
									<li data-transition="boxfade" data-slotamount="7" data-masterspeed="700"  data-saveperformance="off" >
										<!-- MAIN IMAGE -->
										<!--<img src="images/slider/21.jpg"  alt="11"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">-->
											<img src="images/slider/2.jpg"  alt="11"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
										<!-- LAYERS -->
										
									</li>
									<!-- SLIDE  -->
									<li data-transition="boxfade" data-slotamount="7" data-masterspeed="700"  data-saveperformance="off" >
										<!-- MAIN IMAGE -->
										<!--<img src="images/slider/21.jpg"  alt="11"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">-->
											<img src="images/slider/3.jpg"  alt="11"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
										<!-- LAYERS -->
										
									</li>
									<!-- SLIDE  -->
									<li data-transition="boxfade" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
										<!-- MAIN IMAGE -->
										<img src="images/slider/4.jpg"  alt="21"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
										<!-- LAYERS -->
									</li>
									<!-- SLIDE  -->
									<!-- SLIDE  -->
									<li data-transition="boxfade" data-slotamount="7" data-masterspeed="700"  data-saveperformance="off" >
									<!-- MAIN IMAGE -->
										<img src="images/slider/5.jpg"  alt="11"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
										<!-- LAYERS -->
									</li>
									<!-- SLIDE  -->
									<li data-transition="boxfade" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
										<!-- MAIN IMAGE -->
										<img src="images/slider/6.jpg"  alt="31"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
										<!-- LAYERS -->
										
									</li>
								</ul>
								<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>	
							</div>

							<script type="text/javascript">
							/******************************************-PREPARE PLACEHOLDER FOR SLIDER-******************************************/
							var setREVStartSize = function() {
							var	tpopt = new Object();
							tpopt.startwidth = 1160;
							tpopt.startheight = 500;
							tpopt.container = jQuery('#rev_slider_2_1');
							tpopt.fullScreen = "off";
							tpopt.forceFullWidth="off";
							tpopt.container.closest(".rev_slider_wrapper").css({height:tpopt.container.height()});tpopt.width=parseInt(tpopt.container.width(),0);tpopt.height=parseInt(tpopt.container.height(),0);tpopt.bw=tpopt.width/tpopt.startwidth;tpopt.bh=tpopt.height/tpopt.startheight;if(tpopt.bh>tpopt.bw)tpopt.bh=tpopt.bw;if(tpopt.bh<tpopt.bw)tpopt.bw=tpopt.bh;if(tpopt.bw<tpopt.bh)tpopt.bh=tpopt.bw;if(tpopt.bh>1){tpopt.bw=1;tpopt.bh=1}if(tpopt.bw>1){tpopt.bw=1;tpopt.bh=1}tpopt.height=Math.round(tpopt.startheight*(tpopt.width/tpopt.startwidth));if(tpopt.height>tpopt.startheight&&tpopt.autoHeight!="on")tpopt.height=tpopt.startheight;if(tpopt.fullScreen=="on"){tpopt.height=tpopt.bw*tpopt.startheight;var cow=tpopt.container.parent().width();var coh=jQuery(window).height();if(tpopt.fullScreenOffsetContainer!=undefined){try{var offcontainers=tpopt.fullScreenOffsetContainer.split(",");jQuery.each(offcontainers,function(e,t){coh=coh-jQuery(t).outerHeight(true);if(coh<tpopt.minFullScreenHeight)coh=tpopt.minFullScreenHeight})}catch(e){}}tpopt.container.parent().height(coh);tpopt.container.height(coh);tpopt.container.closest(".rev_slider_wrapper").height(coh);tpopt.container.closest(".forcefullwidth_wrapper_tp_banner").find(".tp-fullwidth-forcer").height(coh);tpopt.container.css({height:"100%"});tpopt.height=coh;}else{tpopt.container.height(tpopt.height);tpopt.container.closest(".rev_slider_wrapper").height(tpopt.height);tpopt.container.closest(".forcefullwidth_wrapper_tp_banner").find(".tp-fullwidth-forcer").height(tpopt.height);}
							};

							/* CALL PLACEHOLDER */
							setREVStartSize();
							var tpj=jQuery;
							tpj.noConflict();
							var revapi2;
							tpj(document).ready(function() {
							if(tpj('#rev_slider_2_1').revolution == undefined)
							revslider_showDoubleJqueryError('#rev_slider_2_1');
							else
							revapi2 = tpj('#rev_slider_2_1').show().revolution(
							{
							dottedOverlay:"none",
							delay:9000,
							startwidth:1160,
							startheight:500,
							hideThumbs:200,
							thumbWidth:100,
							thumbHeight:50,
							thumbAmount:3,
							simplifyAll:"off",
							navigationType:"bullet",
							navigationArrows:"solo",
							navigationStyle:"round",
							touchenabled:"on",
							onHoverStop:"on",
							nextSlideOnWindowFocus:"off",
							swipe_threshold: 0.7,
							swipe_min_touches: 1,
							drag_block_vertical: false,
							keyboardNavigation:"off",
							navigationHAlign:"center",
							navigationVAlign:"bottom",
							navigationHOffset:0,
							navigationVOffset:20,
							soloArrowLeftHalign:"left",
							soloArrowLeftValign:"center",
							soloArrowLeftHOffset:20,
							soloArrowLeftVOffset:0,
							soloArrowRightHalign:"right",
							soloArrowRightValign:"center",
							soloArrowRightHOffset:20,
							soloArrowRightVOffset:0,
							shadow:0,
							fullWidth:"on",
							fullScreen:"off",
							spinner:"spinner0",
							stopLoop:"off",
							stopAfterLoops:-1,
							stopAtSlide:-1,
							shuffle:"off",
							autoHeight:"off",
							forceFullWidth:"off",
							hideTimerBar:"on",
							hideThumbsOnMobile:"off",
							hideNavDelayOnMobile:1500,
							hideBulletsOnMobile:"off",
							hideArrowsOnMobile:"off",
							hideThumbsUnderResolution:0,
							hideSliderAtLimit:0,
							hideCaptionAtLimit:0,
							hideAllCaptionAtLilmit:0,
							startWithSlide:0					
							});
							});	/*ready*/
							</script>
						</div><!-- END REVOLUTION SLIDER -->
						<div class="cl"></div>
					</div>
				</section>
				<!--Finish Top -->
				<!--<div class="content_wrap fullwidth">
				
					<section id="middle_content" >
				<div class="alert info">
  <span class="closebtn">&times;</span>  
  <strong>Annual General Meeting held on 29/09/2019 Sunday at Garhwal Bhawan Panchkuin Road,Near Jhandewalan, New Delhi.</strong>
</div>
</section>
	</div>-->
				
<script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
  close[i].onclick = function(){
    var div = this.parentElement;
    div.style.opacity = "0";
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
				<!--Finish Top -->
				<div class="content_wrap fullwidth">
					<!--Start Content-->
					<section id="middle_content" >
						<div class="entry">
							<div class="cmsms_cc">
								<!--<div class="one_first first_column" >
									<div class="cmsms_wrap_latest_bottom_tweets">
										<div id="cmsms_latest_bottom_tweets">
											<ul class="jta-tweet-list responsiveContentSlider">
												<li >Next Holiday - 26th January, 2015 (REPUBLIC DAY) </li>
												<li>Interest Rate @ 18% Per Annum on Balance Loan Amount.</li>
												<li>The Society is administered by an elected board of Directors.</li>
												<li>Society accounts are fully computerized. </li>
												<li>General Body Meetings and Elections are held regularly.</li>
												<li>The Society gives 1% extra interest on deposite to senior citizen. </li>
												<li>Air Conditioned,Computerized and well furnished office.</li>
												<li>Payment through NEFT/RTGS & Deposit facility through Net Banking.</li>
												<li>Well behaved and co-operative staff.</li>
												<li>Compuertized passbook issued to members.</li>
												<li>A cheque of Rs.1100/- as Shagun at time of Son/Daughter/Self-Marriage of member.</li>
												<li>Cash award of Rs.500/- to meritorious students of 10th or 12th classes securing 85% or More marks. </li>
											</ul>
										 </div>
									</div>
									<script type="text/javascript">
										 jQuery(document).ready(function () { 
											jQuery('#cmsms_latest_bottom_tweets .jta-tweet-list').cmsmsResponsiveContentSlider( {
												sliderWidth : '100%',
												sliderHeight : 'auto',
												animationSpeed : 500,
												animationEffect : 'fade',
												animationEasing : 'easeInOutExpo',
												pauseTime : 7000,
												activeSlide : 1, 
												touchControls : true,
												pauseOnHover : false, 
												arrowNavigation : true, 
												slidesNavigation : false 
											} );
										 } );
									</script>
								</div>-->
								<div class="one_first first_column" >
									<marquee direction="left" scrolldelay="150" style="text-transform:uppercase;background: #f47c47;color:#fff;padding:5px;">
										<p class="mar">19th Annual General Body Meeting of the Shree Badri Kedar Co-op. Urban T/C Society Ltd. will be held on SUNDAY, 27th March, 2022 at DDA Community Centre, Mohammadpur Village, Near Sector No. : 1, R K Puram, New Delhi 110066 at 9.30 A.M.Sharp.</p>
									</marquee>
									<div >
									   <h1><span style="font-size: 40px;">WELCOME <span style="font-weight: 400;">to</span> SBK SOCIETY </span></h1>
									</div>
								</div>
								
								<div class="one_third first_column">
									<div >
									   <h2 style="text-align: left;"><strong>Our</strong>  Vision</h2>
									  <a href="aboutus.php"> <img class="fullwidth" src="images/home-gsfc.jpg" title="" alt="" ></a>
									  <p>Our mission of the Society is to encourage members to do more savings habit and to provide financial help loans facilities to them for useful purposes at very reasonable interest rates and minimum formalities. The SBK society is here with an ultimate aim of improving the living standard of the members.  </p>
										<p><a class="more_button" href="aboutus.php">Read more</a></p>
									</div>
									
								</div>
								<div class="one_third">
									<div >
									   <h2 style="text-align: left;"><strong>Member</strong> Benefits</h2>
									  <a href="schemes.php"> <img class="fullwidth" src="images/home-Teflon.jpg" title="" alt="" ></a>
									  <p> Become a member of SBK Society and attain the financial support and improve the standard of living. The society provides various FD schemes for members so that they can meet their financial goals. Click below to know more about the benefits of SBK Society for their members. </p>
										<p><a class="more_button" href="schemes.php">Read more</a></p>
									</div>
								</div>
								<div class="one_third">
									<div >
									   <h2 style="text-align: left;"><strong>Become</strong>  a Member</h2>
										<a href="download/form/membership form.jpg"><img class="fullwidth" src="images/home-ttp.jpg" title="" alt="" ></a>
									  <p>Any person who is resident of Delhi or working in Delhi can become member of Society. But He/She should have reached the age of 18. An at least four introducer is needed to become member of the society. Introducer should be member of the society with clean record. After all formalities, The society can decide to approve membership request or not. He/She can download member application form under our downloading section.  </p>
									</div>
								</div>
								
							
								<div class="one_first first_column" >
									<div >
										<div class="cl"></div>
									</div>
								</div>
								<hr/>
								
								
								
								<div class="one_third first_column">
									<div >
									   <h2 style="text-align: left;"><strong>Meeting</strong>  Agenda</h2>
									                                <div class="download">
																		<a href="upload/agenda/meeting_agenda.pdf" target="_blank">(Click here to Download)</a>
																	</div>
								
									</div>
									
								</div>
								<div class="one_third">
									<div >
									   <h2 style="text-align: left;"><strong>Election</strong> Agenda</h2>
									  <div class="download">
																		<a href="upload/agenda/election_agenda_2022.pdf" target="_blank">(Click here to Download)</a>
																	</div>
									</div>
								</div>
								<div class="one_third">
									<div >
									   <h2 style="text-align: left;"><strong>Balance Sheet</strong>  2020-2021</h2>
										<div class="download">
																		<a href="upload/agenda/bs2020-21.pdf" target="_blank">(Click here to Download)</a>
																	</div>
									</div>
								</div>
								
							
								<div class="one_first first_column" >
									<div >
										<div class="cl"></div>
									</div>
								</div>
								<hr/>
								
								
								
								
			
								
								
								
								
								
								
								
								
								<div class="one_fourth first_column" >
									<div >
									   <h2>SOCIETY GENERAL REPORTS</h2>
									</div>
									<div data-folder="text" data-type="">
										<ul>
											<li style="border:none;"><a href="agm-sgbm-details.php"><span>Managing Committee Reports</span></a></li>
											<li ><a href="bearer-details.php"><span>Bearer Details</span></a></li>
											<li><a href="election-details.php">Election Details </a></li> 
											<li ><a href="annual-returns.php">Annual Returns</a></li>
											<li><a href="audit-details.php">Audit Reports</a></li>
											<li ><a href="bye-laws.php">Bye Laws</a></li>
										</ul> 
									</div>
								</div>
								<div class="one_half" >
									<div >
									   <h2>ABOUT SOCIETY </h2>
									</div>
									<div >
										<h5>Shree Badri Kedar Cooperative Urban Thrift & Credit Society Ltd. was formed in the year 2002.</h5>
										<p> Society is registered by Delhi Govt. Under under Delhi C-op. Societies Act 1972. The society when registered there were 200 members at that time and currently there are nearly 3000 plus active members.</p>
										<p><a class="more_button" href="aboutus.php">Read more</a></p>
										<h4 style='color:#f58149;font-size:20px; font-weight:bold;'>ONLINE PAYMENT BANK DETAILS</h4>

<div style='font-size:22px;'><p><strong>Shree Badri Kedar Co-op. Urban T/C Society Ltd</strong></p>
<p><strong>A/C O : 89830200001092</strong></p>
<p><strong>IFSC Code : BARBOVJBCPL</strong></p>
<p><strong>Bank of Baroda, Bhikaji Cama Place</strong></p>
<p><strong>New Delhi 110066</strong></p>
<p><strong>(M) : 7011737950 (messages refer to this no. with UTR code) </strong></p>
	</div>	
										
<!--<div style='font-size:22px;'><p><strong>SHREE BADRI KEDAR CO-OP. URBAN T/C SOCIETY LTD</strong></p>
<p><strong>A/c no.: 602000301000725</strong></p>
<p><strong>IFSC code: VIJB0006020</strong></p>
<p><strong>Vijaya Bank</strong></p>
	</div>--->								</div>
								</div>
																<div class="one_fourth" >
									<div >
									   <h2>DOWNLOAD FORMS</h2>
									</div>
									<div class="content">
										<ul>
																																							<li><a href="upload/form/1604129559_loan application.pdf" target="_blank">Loan Application</a></li>
																																																				<li><a href="upload/form/1572689211_Membership form.pdf" target="_blank">Membership Form</a></li>
																																																				<li><a href="upload/form/1548352577_SBK resignation form.pdf" target="_blank">Resignation Form</a></li>
																																																				<li><a href="upload/form/1507286986_KYC Form.pdf" target="_blank">Kyc Form</a></li>
																																																				<li><a href="upload/form/1433787480_Application for FD.pdf" target="_blank">Application For Fixed Deposit</a></li>
																																			
										</ul> 
									</div>
								</div>
															</div>
						</section>
						<!--Finish Content-->
				</div>
			</section>
			<!--Start Bottom-->
			<script src="jquery/js_jquery-2.2.0.min.js"></script>		
		
<script>
	$(document).ready(function (e){
		$("#frmContact1").on('submit',(function(e){
			e.preventDefault();
			$("#mail-status").hide();
			$('#send-message').hide();
			$('#loader-icon').show();
		//	response.type='message';
			$.ajax({
				url: "sendmyemail_home.php",
				type: "POST",
				dataType:'json',
				data: {
				//"name":$('input[name="name"]').val(),
				"email":$('input[name="email"]').val(),
				//"phone":$('input[name="phone"]').val(),
				//"subject":$('input[name="subject"]').val(),
				"content":$('textarea[name="content"]').val(),
				//"g-recaptcha-response":$('textarea[id="g-recaptcha-response"]').val()
				    
				},				
				success: function(response){
				$("#mail-status").show();
				$('#loader-icon').hide();
				if(response.type == "error") {
					$('#send-message').show();
					$("#mail-status").attr("class","error");				
				} else if(response.type == "message"){
					$('#send-message').hide();
					$("#mail-status").attr("class","success");							
				}
				$("#mail-status").html(response.text);	
				},
				error: function(){} 
			});
		}));
	});
    </script>
    


    <style>

		#message {  padding: 0px 40px 0px 0px; }
		#mail-status {
			padding: 12px 20px;
			width: 100%;
			display:none; 
			font-size: 1em;
			font-family: "Georgia", Times, serif;
			color: rgb(40, 40, 40);
		}
	  .error{background-color: #F7902D;  margin-bottom: 40px;}
	  .success{background-color: #48e0a4; }
		.g-recaptcha {margin: 0 0 25px 0;}	  
	</style>

<section id="bottom">
	<div class="bottom_inner">
		<div class="bottom_content one_fourth_woocommerce">
			<div class="one_fourth">
				<aside class="widget_recent_entries">
					<h5 class="widgettitle">Site Link</h5>
					<ul>			
						<li><a href="index.php" title="">Home</a></li>
						<li><a href="aboutus.php" title="">About Us</a></li>
						<li ><a href="board-of-management.php"><span>Board of Management</span></a></li>
						<li ><a href="gallery.php"><span>Gallery</span></a></li>
					   <li><a href="contactus.php" title="">Contact Us</a> </li>
					</ul>
				</aside>
			</div>
			<div class="one_fourth">
				<aside class="widget_recent_entries">
					<h5 class="widgettitle">Quick Access</h5>
					<ul>			
						
						<li ><a href="emicalculator.php"><span>Loan EMI Calculator</span></a></li>
						<li ><a href="schemes.php"><span>FD Schemes</span></a></li>
						<li ><a href="members-welfare-scheme.php"><span>Members Welfare Scheme</span></a></li>
					</ul>
				</aside>
			</div>
			<div class="cl_resp"></div>
			<div class="one_fourth">
				<aside class="widget_custom_contact_info_entries">
					<h5 class="widgettitle">Contact Info</h5>
					<span class="contact_widget_name"><strong>SBK Society - Head Office </strong></span><br /><br />
					<span class="contact_widget_address">
						<span ><b>Address</b></span><br />
						Choudhary Satbir House, 139-B 1st Floor,<br/> Mohammad Pur, Near Bhikaji Cama Place, New Delhi - 110066, India.
					</span>
					<br /><br />
					<span class="contact_widget_phone"><!--11 26175215-->
						<span style="display:inline-block; width:25%;"><b>Tel:&nbsp;</b></span>011 47028705
					</span>
					<br />
					<span class="contact_widget_phone">
						<span style="display:inline-block; width:25%;"><b>Fax:&nbsp;</b></span>+91 9891955999
					</span>
					<br />
					<span class="contact_widget_phone">
						<span style="display:inline-block; width:25%;"><b>Email:&nbsp;</b></span>sbktcsociety@gmail.com 
					</span>
	
					
				</aside>
				
			</div>
			<div class="one_fourth">
				 <aside  class="widget_custom_contact_form_entries">
					 <h5 class="widgettitle">Contact us</h5>
					 <div class="cmsms-form-builder">
						<form id="frmContact1" action="" method="POST" novalidate="novalidate">
						   <div class="form_info cmsms_input">
							  <label for="">Your email <span class="color_3">*</span></label>
							  <div class="form_field_wrap">
								 <input type="text" vid="email" name="email" alue="" class="validate[required]" />
							  </div>
						   </div>
						   <div class="cl"></div>
						   <div class="form_info cmsms_textarea">
							  <label for="">Message</label>
							  <div class="form_field_wrap">
								 <textarea  cols="30" rows="6" id="comment-content" name="content"></textarea>
							  </div>
						   </div>
						   <div class="cl"></div>
						  	<div id="mail-status"></div>
						   <div class="fl">	<button style="border:0px;" class="button_small" type="Submit" id="send-message" style="clear:both;">Send Message</button></div>
						   <div class="cl"></div>
						</form>
							<div id="loader-icon" style="display:none;"><img src="loader.gif" /></div>
					 </div>
				  </aside>
			</div>
		</div>
	</div>
</section>			<!--Finish Bottom-->
			<a href="javascript:void(0);" id="slide_top"></a>
		</div>
		<!--Finish Container-->
		<!--Start Footer-->
		<footer id="footer" role="contentinfo">
	<div class="footer_inner">
		<span class="copyright"><b>&copy; 2014. SBK Society. Designed By: <a href="http://www.delightaid.com/" target="_blank">Delightaid</a></b></span>
		<ul class="social_icons">
			<li>
			   <a target="_blank" href="#" title="LinkedIn">
			   <img src="images/linkedin.png" alt="#" />
			   </a>
			</li>
			<li>
			   <a target="_blank" href="#" title="Facebook">
			   <img src="images/facebook.png" alt="#" />
			   </a>
			</li>
			<li>
			   <a href="#" title="Google">
			   <img src="images/google-plus.png" alt="#" />
			   </a>
			</li>
			
			<li>
			   <a href="#" title="Twitter">
			   <img src="images/twitter.png" alt="#" />
			   </a>
			</li>
		</ul>
	</div>
</footer>
		<!--Finish Footer-->
	</section>   
	<div class="revsliderstyles">
		<style type="text/css">												
			.tp-caption.cmsms_large_text{position:absolute; color:#323232;text-shadow:none; font-weight:700;font-size:24px; line-height:40px;font-family:"Raleway";margin:0px;padding:10px 0px 10px 20px; border-width:0px; border-style:none; border-left-width:4px; border-left-style:solid; border-left-color:#cc3300; white-space:nowrap}
			.tp-caption.cmsms_medium_text{position:absolute;color:#757575;text-shadow:none;font-weight:400;font-size:16px;line-height:24px;font-family:Arial;margin:0px;border-width:0px;border-style:none;white-space:nowrap}.tp-caption.medium_text{position:absolute;color:#fff;text-shadow:0px 2px 5px rgba(0,0,0,0.5);font-weight:700;font-size:20px;line-height:20px;font-family:Arial;margin:0px;border-width:0px;border-style:none;white-space:nowrap}
			.cmsms_large_text{position:absolute;color:#323232;text-shadow:none;font-weight:700;font-size:24px;line-height:40px;font-family:"Raleway";margin:0px;padding:10px 0px 10px 20px; border-width:0px; border-style:none; border-left-width:4px; border-left-style:solid; border-left-color:#cc3300;white-space:nowrap}
			.cmsms_medium_text{position:absolute;color:#757575;text-shadow:none;font-weight:400;font-size:16px;line-height:24px;font-family:Arial;margin:0px;border-width:0px;border-style:none;white-space:nowrap}.medium_text{position:absolute;color:#fff;text-shadow:0px 2px 5px rgba(0,0,0,0.5);font-weight:700;font-size:20px;line-height:20px;font-family:Arial;margin:0px;border-width:0px;border-style:none;white-space:nowrap}
		</style>
	</div>
	<!--Start Footer-->
	<script type='text/javascript' src='wp-content/themes/website/js/jquery.easing.min6f3e.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jackbox-lib8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jackbox8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jquery.script8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jquery.tweet.mine7f0.js'></script>	<!--Finish Footer-->
</body>
</html>