<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US"><![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
    <!--<![endif]-->    
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>BK Society || Home</title>
		<!--Start Header script-->
		<link rel='stylesheet' href='wp-content/plugins/LayerSlider/css/layerslider2cb6.css' type='text/css' media='all' />
<link rel='stylesheet'   href='wp-content/plugins/revslider/rs-plugin/css/settings84bb.css' type='text/css' media='all' />
<style type='text/css'>
   .tp-caption a{color:#57a2bc;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#323232}
</style>
<link rel='stylesheet' href='wp-content/themes/website/style.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/fonts8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/adaptive8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/cmsms-woocommerce-style8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jackbox8a54.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jquery.jPlayer3c94.css' type='text/css' media='screen' />
<link rel='stylesheet'   href='wp-content/themes/website/css/jquery.isotope5d6b.css' type='text/css' media='screen' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='theme-ie-css'  href='http://industrial.cmsmasters.net/wp-content/themes/website/css/ie.css?ver=1.0.0' type='text/css' media='screen' />
<![endif]-->
<!--[if lt IE 9]>
<link rel='stylesheet' id='theme-ieCss3-css'  href='http://industrial.cmsmasters.net/wp-content/themes/website/css/ieCss3.php?ver=1.0.0' type='text/css' media='screen' />
<![endif]-->
<link rel='stylesheet'   href='http://fonts.googleapis.com/css?family=Raleway%3A200%2C400%2C500%2C600%2C700&amp;ver=3.9.2' type='text/css' media='all' />
<script type='text/javascript' src='wp-content/themes/website/js/modernizr.custom.all.min16b9.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/respond.minf488.js'></script>
<script type='text/javascript' src='jquery/jquery.js'></script>
<script type='text/javascript' src='jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/layerslider.kreaturamedia.jquery2cb6.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/jquery-easing-1.36f3e.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/jquerytransite2dc.js'></script>
<script type='text/javascript' src='wp-content/plugins/LayerSlider/js/layerslider.transitions2cb6.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min84bb.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min84bb.js'></script>
<script type="text/javascript">var templateURL = "wp-content/themes/website/index.php";</script>
<style type="text/css">
	body {background-color :#ffffff; background-image :none; background-position :top center; background-repeat:repeat; background-attachment : scroll;}
	#middle.cmsms_middle_margin{margin-top:110px; }
	#header > .header_inner { height : 120px; }
	#header.fixed_header + * { margin-top : 100px; }
	#header > .header_inner > a.logo { top : 10px; left : 0px; } 
	.header_inner:after { width : 255px; } 
	#header > .header_inner > a.logo > img { width : 170px; height : 100px; }
	#header nav { top : 55px; left : 200px; } 
	#header .social_icons { top : 55px; left : 255px; } 
	#header .search_line { top : 95px; left : 255px; } 
	.header_html { top : 15px; right : 0px; }
	#header.fixed_header > .header_inner { height : 110px; }
	#header.fixed_header > .header_inner > a.logo { top : 10px; }
	#header.fixed_header nav { top : 50px; } 
	#header.fixed_header .social_icons { top : 60px; } 
	#header.fixed_header .search_line { top : 90px; }
	@media only screen and (max-width : 1024px) { .cmsms_responsive #middle.cmsms_middle_margin { margin-top : 0px; } .cmsms_responsive .header_inner:after { margin-left : 5%; } .cmsms_responsive #header nav { top : auto; left : auto; } .cmsms_responsive #header > .header_inner > a.logo { top : auto; left : auto; } .cmsms_responsive #header > .header_inner { height : auto; } }
	@media only screen and (max-width : 767px) 
	{ 
		.cmsms_responsive #header .search_line, .cmsms_responsive #header .social_icons { top : auto; left : auto; } 
	} 
	@media only screen and (max-width : 450px) 
	{ 
		.cmsms_responsive .header_html { top : auto; }
		.cmsms_responsive #header > .header_inner > a.logo { width : 90%; height : auto; } 
		.cmsms_responsive #header > .header_inner > a.logo > img { margin : 0 auto; } 
		.cmsms_responsive .header_inner:after { width : 90%; } 
	} 
</style>
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;background:none !important; }</style>		<!--Finish Header script-->
	</head>
	<body >
		<!--Start Page-->
		<section id="page" class="csstransition cmsms_responsive hfeed site">
			<a href="#" id="slide_top"></a>
			<!--Start Container-->
			<div class="container set_fixed">
				<!--Start Header-->
				<header class="header_position" id="header">
	<div class="header_inner">
		<a href="index.php" title="SHREE BADRI KEDAR CO-OPERATIVE" class="logo">
			<img src="wp-content/themes/website/img/logo.png" alt="SHREE BADRI KEDAR CO-OPERATIVE" />
		</a>
		<div style="font-size:25px;top:10px;left:220px;position:absolute;font-weight:bold;color:#f58149;line-height:30px;">
			SHREE BADRI KEDAR CO-OPERATIVE <br/>URBAN THRIFT & CREDIT SOCIETY LTD. <span style="font-size:13px;font-weight:bold;color:#000;">Registration no.: S/W 16(U)/2002</span>
		</div>
		
		<!--<a class="search_but" href="javascript:void(0);"></a>
		<a class="social_but social_but_fixed" href="javascript:void(0);"></a>-->
			
		<!--Start Navigation-->
		<nav role="navigation" class="">
			<ul id="navigation" class="navigation">
				<li class="current-menu-ancestor current-menu-parent"><a href="index.php"><span>Home</span></a> </li>
				<li ><a href="aboutus.php"><span>About Us</span></a></li>
				<li class="dropdown">
					<a href="#"><span>Management</span></a>
					<ul class="sub-menu">
						<li ><a href="board-of-management.php"><span>Board of Management </span></a></li>
						<li ><a href="gallery.php"><span>Gallery</span></a></li>
					</ul>
				</li>
				<li><a href="contactus.php"><span>Contact Us</span></a></li>
				<li class="dropdown">
					<a href="#"><span>Quick Access</span></a>
					<ul class="sub-menu">
						<!--<li ><a href="member-list.php"><span>Member List </span></a></li>-->
						<li ><a href="emicalculator.php"><span>Loan EMI Calculator</span></a></li>
						<li ><a href="schemes.php"><span>FD Schemes</span></a></li>
						<li ><a href="members-welfare-scheme.php"><span>Members Welfare Scheme</span></a></li>
						
					</ul>
				</li>
				<li ><a href="bkadmin/" target="_blank"><span>Admin login</span></a></li>
			</ul>
		</nav>
		<!-- <div class="search_line">
		   <form method="get" action="#">
				<div class="one_half first_column">
					 <input placeholder="User Id" value="" type="text">
				</div>
				<div class="one_half">
					 <input placeholder="password" value="" type="password">  <input placeholder="LogIn" value="Login" type="button" class="button_small">
				</div> 
				
		   </form>
		</div>
		<ul class="social_icons">
			<li>
			   <a target="_blank" href="#" title="LinkedIn">
			   <img src="images/linkedin.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="LinkedIn">LinkedIn</a>
			</li>
			<li>
			   <a target="_blank" href="#" title="Facebook">
			   <img src="images/facebook.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Facebook">Facebook</a>
			</li>
			<li>
			   <a href="#" title="Google">
			   <img src="images/google-plus.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Google">Google</a>
			</li>
			
			<li>
			   <a href="#" title="Twitter">
			   <img src="images/twitter.png" alt="#" />
			   </a>
			   <a class="cmsms_icon_title" href="#" title="Twitter">Twitter</a>
			</li>
		</ul>
		<div class="cl"></div>-->
		<!-- _________________________ Finish Navigation _________________________ -->
	</div>
</header>				<!--Finish Header-->
				<!-- _________________________ Start Middle _________________________ -->
				<section id="middle" class=" cmsms_middle_margin">
					<div class="headline">
						<div class="width100">
							<div><h1 class="heading_title_nomg">FD Schemes</h1></div>
							<div class="cmsms_breadcrumbs">
								<a href="index.php" class="home"></a>
								<span class="breadcrumbs_sep"> / </span>
								<a href="#" >Quick Access</a>
								<span class="breadcrumbs_sep"> / </span>
								<span><b>FD Schemes</b></span>
							</div>
						</div>
					</div>
					<div class="content_wrap l_sidebar">
						<!--Start Content-->
						<section id="content" class="fr" role="main">
							<div class="entry">
								<div class="cmsms_cc">
								
								<h2>Member benefits of  Shree Badri Kedar Co-Operative Urban Thrift & Credit Society LTD.</h2>
								<div class="content">
										<!--<ol>
											<li >Maximum Loan Limit is Rs. 3,00,000/-(Three Lakh Only).</li >
											<li >Emergency Loan Limit is Rs. 20,000/- (Twenty Thousand Only)</li >
											<li >In case of Death of member Rs.10,000/-(Ten Thousand Only) are provided to family as Immediate Relief.</li >
											<li >In case after Death of member if there is any loan pending , maximum rebate upto Rs. 50,000/-(Fifty Thousand Only) is provided to his or her family so that family does not feel burdened.</li >
											<li >Society also provides Rs. 751/- as Kanyadan in case of Marriage of Members Daughter and Self marriage of lady member and Rs. 501/- as Shagun in case of Sons Marriage and self marriage of gents member.</li >
											<li >Society also provides Rs. 2100- as Kanyadan in case of Self Marriage of Lady Member whose both father and mother or any one of them is not alive and Rs. 1100/- as Shagun in case of Self marriage of gents member whose both father and mother or any one of them is not alive.</li >
											<li >Society also provides Rs. 2100/- as Kanyadan in case of Marriage of Gents Members Daughter if his wife is not alive or marriage of female members daughter if her husband is not alive and Rs. 1100/- as Shagun in case of Sons Marriage of Gents Members if his wife is not alive or marriage of female members son if her husband is not alive.</li >
											<li >Society also provides Rs. 1100/- on birth of Daughter or Grand Daughter of Member.</li >
											<li >Interest on Fixed Deposit to members @ 10% for 1 year & @ 11% for 2 to 5 years.</li >
											<li >Widows and Senior Citizens can collect their interest on Fixed Deposit monthly @ 10.50% for 1 year & @ 11.50% for 2 to 5 years.</li >
											<li >Members are honored by momento and cash reward of Rs. 1100/- (Eleven hundred only) if they are honored by Delhi Govt., Central Govt. or autonomous bodies.</li >
											<li >On members Retirement momento and shawl is given by the society.</li >
											<li >Senior Citizens above 65 years are honored with gift by society every year.</li >
										</ol>		
										<h4>Society Also Provides Cash Reward and Gift To Students:</h4>	
										<ol>
											<li >Students of class 1st to 5th with 90% or above percentage are given cash reward of Rs. 351/- and a gift.</li >
											<li >Students of class 6th to 9th with 85% or above percentage are given cash reward of Rs. 501/- and a gift.</li >
											<li >Students of class 10th, 11th, 12th with 75 % or above percentage are given cash reward of Rs. 751/- and a gift.</li >
											<li >Students who have completed Degree (3 Years or 4 Years) or Diploma (Two Year) with 60 % or above percentage are given scholarship of Rs. 1251/-. If student has completed Degree in higher courses (Medical, B.Tech, M.Tech, Company Secretary, Chartered Accountant etc.) then management has the right to consider the case under this category of scholarship.
											</li>
										</ol>
										<h4>Schemes List </h4>
										<p><b>BRIEF PARTICULARS OF DEPOSIT SCHEMES (effective from 11 feb. 2011)</b></p>
										<table class="table">
											<thead>
												<tr>
													
													<th width="25%">SCHEMES</th>
													<th width="20%">RATE OF INTEREST (P.A)</th>
													<th width="15%">INTEREST PAYABLE</th>
													<th width="15%">PERIOD</th>
													<th width="25%">REMARKS</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>SCHEME – A <br/>NON CUMULATIVE QUARTERLY</td>
													<td>10%</td>
													<td>Quarterly</td>
													<td>
														24 Months<br/>
														36 Months<br/>
														48 Months<br/>
														60 Months
													</td>
													<td>
														Minimum Rs. 50,000/-& in multiple of Rs. 10,000/-
													</td>
												</tr>
												<tr>
													<td>SCHEME – B <br/>NON COMULATIVE</td>
													<td>
														(i)	 9%<br/>
														(ii)	10%<br/>
														(iii)	11%<br/>
														(iv)	12%
													</td>
													<td>
														On Maturity<br/>
														On Maturity<br/>
														On Maturity<br/>
														On Maturity
													</td>
													<td>
														6 Months<br/>
														12 Months<br/>
														24 Months<br/>
														36 Months Onwords
													</td>
													<td>
														Minimum Rs. 10,000/- & in Multiple of Rs. 1000/-
													</td>
												</tr>
												<tr>
													<td>RECURRING DEPOSIT (RD)</td>
													<td>
														10%     
													</td>
													<td>
														On Maturity     
													</td>
													<td>
														
														12 Months<br/>
														24 Months<br/>
														36 Months<br/>
														48 Months
													</td>
													<td>
														Min. Rs. 500/- Month
													</td>
												</tr>
												<tr>
													<td>SBK BOND   </td>
													<td colspan="4">
														Double within 6.8 Years (80 Months) Min. Rs. 10,000/-    
													</td>
													
												</tr>
											</tbody>
										</table>
										
										-->
										<h4>Schemes List </h4>
										<p><b>BRIEF PARTICULARS OF DEPOSIT SCHEMES (effective from 10th April. 2019)</b></p>
										<!--<table class="table">
											<thead>
												<tr>
													
													<th width="25%">SCHEMES</th>
													<th width="20%">RATE OF INTEREST (P.A)</th>
													<th width="15%">INTEREST PAYABLE</th>
													<th width="15%">PERIOD</th>
													<th width="25%">REMARKS</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>SCHEME – A <br/>NON CUMULATIVE MONTHLY</td>
													<td>8%</td>
													<td>MONTHL</td>
													<td>
														24 Months<br/>
														36 Months<br/>
														48 Months<br/>
														60 Months
													</td>
													<td>
														Minimum Rs. 50,000/-& in multiple of Rs. 10,000/-
													</td>
												</tr>
												<tr>
													<td>SCHEME – B <br/>NON COMULATIVE</td>
													<td>
														(i)	 9%<br/>
														(ii)	10%<br/>
														(iii)	11%
														
													</td>
													<td>
														On Maturity<br/>
														On Maturity<br/>
														On Maturity
														
													</td>
													<td>
														
														12 Months<br/>
														24 Months<br/>
														36 Months Onwords
													</td>
													<td>
														Minimum Rs. 10,000/- & in Multiple of Rs. 1000/-
													</td>
												</tr>
												<tr>
													<td>RECURRING DEPOSIT (RD)</td>
													<td>
														9%     
													</td>
													<td>
														On Maturity     
													</td>
													<td>
														
														12 Months<br/>
														24 Months<br/>
														36 Months<br/>
														48 Months
													</td>
													<td>
														Min. Rs. 500/- Month
													</td>
												</tr>
												<tr>
													<td>SBK BOND   </td>
													<td colspan="4">
														Double within 7 Years (84 Months) Min. Rs. 10,000/-    
													</td>
													
												</tr>
												<tr>
													<td>OPTIONAL DEPOSIT (OD) / SAVING A/c  </td>
													<td>
														8%     
													</td>
													<td>
														--
													</td>
													<td>
														
														30 Days<br/>
														
													</td>
													<td>
														Min. Rs. 500/- Month
													</td>
													
												</tr>
												<tr>
													<td>COMPULSORY DEPOSIT </td>
													<td>
														7%     
													</td>
													<td>
														Closing of A/c
													</td>
													<td>
														
														30 Days<br/>
														
													</td>
													<td>
														Min. Rs. 200/- Month
													</td>
													
												</tr>
											</tbody>
										</table>-->
										 <img src="images/fd-Schemes1.jpg" alt="" width="800">
										<p>&nbsp;</p>
										<h4>FIXED DEPOSIT TERMS & CONDITION</h4>
										<div class="content">
											<ol>
												<li >The receipt is not transferable and subject to encashment of cheque/draft.</li >
												<li >Cheque/Drafts in respects of deposits should be payable at Delhi/New Delhi.</li >
												<li >The minimum acceptable amount for opening FD account will be Rs. 1000/-</li >
												<li >All renewals are effected and payment are made from the society registered office at ‘Ch. Satvir House”, 139 B, 1st floor, Nr. BhikajiCama Place, Mohammadpur, new delhi 110066</li >
												<li >The deposit is payable on the due date indicated. It shall not carry interest beyond the due date unless renewed. </li >
												<li >Intimation regarding change of address, if any should reach the society at least one month before the due date of payment of principal/interest.</li > 
												<li >The society reserve the right of paying up any F.D before the date of maturity. </li >
												<li >Refund of deposit before maturity date shall be at the description of the society. In case of refund of deposit before maturity date, payment of interest will be in accordance with the rate decided by the society. </li >
											</ol>
										</div>									
									
									<!--<table class="table">
										<thead>
											<tr>
												
												<th>Scheme Name</th>
												<th>Start Date</th>
												<th>End Date</th>
												<th>Scheme Details</th>
												<th>Application Form</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												
												<td>Deposite Scheme</td>
												<td>11/02/2011</td>
												<td>--</td>
												<td>
													<div class="download">
														<a href="download/scheme/FD-scheme.pdf" target="_blank">(Click here to Download)</a></li>
													</div>
												</td>
												<td>
													<div class="download">
														<a href="download/scheme/FD-scheme-form.pdf" target="_blank">(Click here to Download)</a></li>
													</div>
												</td>
											</tr>
											
										</tbody>
									</table>-->
								</div>
							</div>
						</section>
						<!--Finish Content-->
						<!--Start Sidebar -->
						<section id="sidebar" class="fl" >
							<div class="one_first">
	<aside id="recent-posts-4" class="widget widget_recent_entries">
		<h2 class="widgettitle">Site Links</h2>
		<ul>			
			<li><a href="index.php"><span>Home</span></a> </li>
			<li ><a href="aboutus.php"><span>About Us</span></a></li>
			<li ><a href="board-of-management.php"><span>Board of Management </span></a></li>
			<li ><a href="gallery.php"><span>Gallery</span></a></li>
			<!--<li ><a href="member-list.php"><span>Member List </span></a></li>-->
			<li ><a href="emicalculator.php"><span>Loan EMI Calculator</span></a></li>
			<li ><a href="schemes.php"><span>FD Schemes</span></a></li>
			<li ><a href="members-welfare-scheme.php"><span>Members Welfare Scheme</span></a></li>
			<li><a href="contactus.php"><span>Contact Us</span></a></li>
		</ul>
	</aside>
</div>
<div class="one_first">
	<aside  class="widget widget_recent_entries">
		<h2 class="widgettitle">Society General Reports</h2>
		<ul>
			<li ><a href="agm-sgbm-details.php"><span>Managing Committee Reports</span></a></li>
			<li ><a href="bearer-details.php"><span>Bearer Details</span></a></li>
			<li><a href="election-details.php">Election Details </a></li> 
			 <li ><a href="annual-returns.php">Annual Returns</a></li>
			 <li><a href="audit-details.php">Audit Reports</a></li>
			 <li ><a href="bye-laws.php">Bye Laws</a></li>
		</ul> 
	</aside>
</div>
<div class="one_first">
	<aside class="widget ">
		<h2 class="widgettitle">Download forms</h2>
		<div class="content">
			<ul>
																		<li><a href="upload/form/1604129559_loan application.pdf" target="_blank">Loan Application</a></li>
																								<li><a href="upload/form/1572689211_Membership form.pdf" target="_blank">Membership Form</a></li>
																								<li><a href="upload/form/1548352577_SBK resignation form.pdf" target="_blank">Resignation Form</a></li>
																								<li><a href="upload/form/1507286986_KYC Form.pdf" target="_blank">KYC Form</a></li>
																								<li><a href="upload/form/1433787480_Application for FD.pdf" target="_blank">Application for Fixed Deposit</a></li>
														<!--<li><a href="#">Loan Against Fixed Deposit Form</a></li>
				<li><a href="#">Recurring Deposit Form</a></li>
				<li><a href="#">Resignation Format</a></li>
				<li><a href="#">Payment/Emergency Loan Voucher</a></li>
				<li><a href="#">Recurring Deposit Chart</a></li>
				
				<li><a href="#">Imp.Information's in Hindi</a></li>-->
			</ul> 
		</div>
	</aside>
</div>
						</section>
						<!-- Finish Sidebar -->
						<div class="cl"></div>
					</div>
				</section>
				<!--Start Bottom-->
				<script src="jquery/js_jquery-2.2.0.min.js"></script>		
		
<script>
	$(document).ready(function (e){
		$("#frmContact1").on('submit',(function(e){
			e.preventDefault();
			$("#mail-status").hide();
			$('#send-message').hide();
			$('#loader-icon').show();
		//	response.type='message';
			$.ajax({
				url: "sendmyemail_home.php",
				type: "POST",
				dataType:'json',
				data: {
				//"name":$('input[name="name"]').val(),
				"email":$('input[name="email"]').val(),
				//"phone":$('input[name="phone"]').val(),
				//"subject":$('input[name="subject"]').val(),
				"content":$('textarea[name="content"]').val(),
				//"g-recaptcha-response":$('textarea[id="g-recaptcha-response"]').val()
				    
				},				
				success: function(response){
				$("#mail-status").show();
				$('#loader-icon').hide();
				if(response.type == "error") {
					$('#send-message').show();
					$("#mail-status").attr("class","error");				
				} else if(response.type == "message"){
					$('#send-message').hide();
					$("#mail-status").attr("class","success");							
				}
				$("#mail-status").html(response.text);	
				},
				error: function(){} 
			});
		}));
	});
    </script>
    


    <style>

		#message {  padding: 0px 40px 0px 0px; }
		#mail-status {
			padding: 12px 20px;
			width: 100%;
			display:none; 
			font-size: 1em;
			font-family: "Georgia", Times, serif;
			color: rgb(40, 40, 40);
		}
	  .error{background-color: #F7902D;  margin-bottom: 40px;}
	  .success{background-color: #48e0a4; }
		.g-recaptcha {margin: 0 0 25px 0;}	  
	</style>

<section id="bottom">
	<div class="bottom_inner">
		<div class="bottom_content one_fourth_woocommerce">
			<div class="one_fourth">
				<aside class="widget_recent_entries">
					<h5 class="widgettitle">Site Link</h5>
					<ul>			
						<li><a href="index.php" title="">Home</a></li>
						<li><a href="aboutus.php" title="">About Us</a></li>
						<li ><a href="board-of-management.php"><span>Board of Management</span></a></li>
						<li ><a href="gallery.php"><span>Gallery</span></a></li>
					   <li><a href="contactus.php" title="">Contact Us</a> </li>
					</ul>
				</aside>
			</div>
			<div class="one_fourth">
				<aside class="widget_recent_entries">
					<h5 class="widgettitle">Quick Access</h5>
					<ul>			
						
						<li ><a href="emicalculator.php"><span>Loan EMI Calculator</span></a></li>
						<li ><a href="schemes.php"><span>FD Schemes</span></a></li>
						<li ><a href="members-welfare-scheme.php"><span>Members Welfare Scheme</span></a></li>
					</ul>
				</aside>
			</div>
			<div class="cl_resp"></div>
			<div class="one_fourth">
				<aside class="widget_custom_contact_info_entries">
					<h5 class="widgettitle">Contact Info</h5>
					<span class="contact_widget_name"><strong>SBK Society - Head Office </strong></span><br /><br />
					<span class="contact_widget_address">
						<span ><b>Address</b></span><br />
						Choudhary Satbir House, 139-B 1st Floor,<br/> Mohammad Pur, Near Bhikaji Cama Place, New Delhi - 110066, India.
					</span>
					<br /><br />
					<span class="contact_widget_phone"><!--11 26175215-->
						<span style="display:inline-block; width:25%;"><b>Tel:&nbsp;</b></span>011 47028705
					</span>
					<br />
					<span class="contact_widget_phone">
						<span style="display:inline-block; width:25%;"><b>Fax:&nbsp;</b></span>+91 9891955999
					</span>
					<br />
					<span class="contact_widget_phone">
						<span style="display:inline-block; width:25%;"><b>Email:&nbsp;</b></span>sbktcsociety@gmail.com 
					</span>
	
					
				</aside>
				
			</div>
			<div class="one_fourth">
				 <aside  class="widget_custom_contact_form_entries">
					 <h5 class="widgettitle">Contact us</h5>
					 <div class="cmsms-form-builder">
						<form id="frmContact1" action="" method="POST" novalidate="novalidate">
						   <div class="form_info cmsms_input">
							  <label for="">Your email <span class="color_3">*</span></label>
							  <div class="form_field_wrap">
								 <input type="text" vid="email" name="email" alue="" class="validate[required]" />
							  </div>
						   </div>
						   <div class="cl"></div>
						   <div class="form_info cmsms_textarea">
							  <label for="">Message</label>
							  <div class="form_field_wrap">
								 <textarea  cols="30" rows="6" id="comment-content" name="content"></textarea>
							  </div>
						   </div>
						   <div class="cl"></div>
						  	<div id="mail-status"></div>
						   <div class="fl">	<button style="border:0px;" class="button_small" type="Submit" id="send-message" style="clear:both;">Send Message</button></div>
						   <div class="cl"></div>
						</form>
							<div id="loader-icon" style="display:none;"><img src="loader.gif" /></div>
					 </div>
				  </aside>
			</div>
		</div>
	</div>
</section>				<!--Finish Bottom-->
				<a href="javascript:void(0);" id="slide_top"></a>
			</div>
			<!--Finish Container-->
			<!--Start Footer-->
			<footer id="footer" role="contentinfo">
	<div class="footer_inner">
		<span class="copyright"><b>&copy; 2014. SBK Society. Designed By: <a href="http://www.delightaid.com/" target="_blank">Delightaid</a></b></span>
		<ul class="social_icons">
			<li>
			   <a target="_blank" href="#" title="LinkedIn">
			   <img src="images/linkedin.png" alt="#" />
			   </a>
			</li>
			<li>
			   <a target="_blank" href="#" title="Facebook">
			   <img src="images/facebook.png" alt="#" />
			   </a>
			</li>
			<li>
			   <a href="#" title="Google">
			   <img src="images/google-plus.png" alt="#" />
			   </a>
			</li>
			
			<li>
			   <a href="#" title="Twitter">
			   <img src="images/twitter.png" alt="#" />
			   </a>
			</li>
		</ul>
	</div>
</footer>
			<!--Finish Footer-->
		</section>   
		<!--Start Footer-->
		<script type='text/javascript' src='wp-content/themes/website/js/jquery.easing.min6f3e.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jackbox-lib8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jackbox8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jquery.script8a54.js'></script>
<script type='text/javascript' src='wp-content/themes/website/js/jquery.tweet.mine7f0.js'></script>		<!--Finish Footer-->
	</body>
</html>